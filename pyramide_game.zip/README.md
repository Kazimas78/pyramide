# Jeu Pyramide

Bienvenue dans le jeu Pyramide inspiré du célèbre jeu télévisé avec Marie-Ange Nardy. 

## Comment jouer
- Devinez les mots associés aux indices.
- Chaque bonne réponse rapporte des points.
- Le score total est affiché en haut de la page.

## Installation
Clonez ce dépôt et ouvrez le fichier `index.html` dans votre navigateur pour commencer à jouer.

## Déploiement
Déployez ce projet sur GitHub Pages ou une autre plateforme d'hébergement statique pour y accéder en ligne.
